# matlab_asl_prediction_abcv

TO RUN THE APP, run the main.m file and choose whether to (1) choose random images from the test folder or (2) get a snapshot from a webcam.
Images used were preprocessed and normalize to be black and white and resized to 128x128 to decrease training time and for easier CNN prediction.

The current accuracy is 50.86%.
